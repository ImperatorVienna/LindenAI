# Tesseract component

The executable is built for the platform named in `manifest.json`. The `tessdata` directory contains English, simplified Chinese, and traditional Chinese OCR models. The desktop installs this bundled build into its third-party component directory; updates are read from the `component/tesseract` branch and `main/components.json` in `ImperatorVienna/LindenAI`.

Tesseract and tessdata are Apache-2.0 licensed; see `licenses/`. The Rust core renders PDF pages and passes PNG bytes to this component. The built-in image OCR MCP also calls this executable.
